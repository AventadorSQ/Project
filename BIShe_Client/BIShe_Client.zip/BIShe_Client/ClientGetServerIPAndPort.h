
#define SERVER_IP "47.98.61.33"
#define SERVER_PORT (16300)
#define PUT_PATH "/NormalFile/"
#define BACKUP_TYPE "text/plain"