﻿#pragma once

#include "httplib.h"
#include "ClientGetServerIPAndPort.h"
#include <string>
#include <iostream>

#define GETINFOPATH_PUT_PATH "/GetInfoAndPath/"

//获取指定用户的已备份信息和下载路径
class GetBackupInfoAndPath
{
public:
	GetBackupInfoAndPath(std::string EmailName)
		:_EmailName(EmailName)
	{}
public:
	//查询指定文件是否已经备份
	bool SelectClientFileIsBackup(std::string& FileName)
	{
		//实例化客户端对象
		httplib::Client client(SERVER_IP, SERVER_PORT);

		//组织HTTP格式请求
		httplib::Headers hdr;
		hdr.clear();
		std::string ClientQuerySelect;
		ClientQuerySelect.resize(1);
		ClientQuerySelect[0] = '1';
		hdr.insert(make_pair("EmailName", _EmailName));
		hdr.insert(make_pair("FileName", FileName));
		hdr.insert(make_pair("ClientQuerySelect", ClientQuerySelect.c_str()));
		//发送请求
		std::string uri = GETINFOPATH_PUT_PATH;
		std::string body("hh");
		auto rsp = client.Put(uri.c_str(), hdr, body, BACKUP_TYPE);
		//分析响应信息
		if (rsp->status == 200)
		{
			//所查询文件已经备份
			std::cout << rsp->body << std::endl;
			return true;
		}
		else
		{
			//所查询文件没有备份
			std::cout << rsp->body << std::endl;
			return false;
		}
	}

	//获取该用户所有文件名
	void GetClientAllFileName()
	{
		//实例化客户端对象
		httplib::Client client(SERVER_IP, SERVER_PORT);

		//组织HTTP格式请求
		httplib::Headers hdr;
		hdr.clear();
		std::string ClientQuerySelect;
		ClientQuerySelect.resize(2);
		ClientQuerySelect[0] = '1';
		ClientQuerySelect[1] = '2';
		hdr.insert(make_pair("EmailName", _EmailName));
		hdr.insert(make_pair("ClientQuerySelect", ClientQuerySelect.c_str()));
		//发送请求
		std::string uri = GETINFOPATH_PUT_PATH;
		std::string body("hh");
		auto rsp = client.Put(uri.c_str(), hdr, body, BACKUP_TYPE);
		if (rsp->status != 200)
		{
			std::cout << rsp->body << std::endl;
			return;
		}
		//std::cout << rsp->body << " 76" << std::endl;
		//return;
		//打印该用户备份文件名
		size_t BodySize = 0;
		size_t pos = rsp->body.find('\n');
		size_t temp = pos;
		while (pos != string::npos)
		{
			temp = pos + 1;
			pos = rsp->body.find('\n', temp);
			BodySize++;
		}
		std::cout << "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" << std::endl;
		std::cout << "++++++++++++     你已经备份了:" << BodySize << "份文件" << std::endl;
		std::cout << "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" << std::endl;
		std::cout << "---------------------------------------------------------------------------------------------------" << std::endl;
		size_t pos1 = 0;
		size_t pos2;
		for (size_t i = 0; i < BodySize; i++)
		{
			pos2 = rsp->body.find('\n', pos1);
			std::string FileName;
			FileName = rsp->body.substr(pos1, pos2 - pos1);
			pos1 = pos2 + 1;
			std::cout << "[" << i + 1 << "]:" << FileName << std::endl;
		}
		std::cout << std::endl;
		std::cout << "---------------------------------------------------------------------------------------------------" << std::endl;
	}

	//获取该用户所有文件的详细信息即：文件名及大小
	void GetClientAllFileNameAndSize()
	{
		//实例化客户端对象
		httplib::Client client(SERVER_IP, SERVER_PORT);

		//组织HTTP格式请求
		httplib::Headers hdr;
		hdr.clear();
		std::string ClientQuerySelect;
		ClientQuerySelect.resize(3);
		ClientQuerySelect[0] = '1';
		ClientQuerySelect[1] = '2';
		ClientQuerySelect[2] = '3';
		hdr.insert(make_pair("EmailName", _EmailName));
		hdr.insert(make_pair("ClientQuerySelect", ClientQuerySelect.c_str()));
		//发送请求
		std::string uri = GETINFOPATH_PUT_PATH;
		std::string body("hh");
		auto rsp = client.Put(uri.c_str(), hdr, body, BACKUP_TYPE);
		if (rsp->status != 200)
		{
			std::cout << rsp->body << std::endl;
			return;
		}

		//打印该用户备份文件名及文件大小
		size_t BodySize = 0;
		size_t pos = rsp->body.find('\n');
		size_t temp = pos;
		while (pos != string::npos)
		{
			temp = pos + 1;
			pos = rsp->body.find('\n', temp);
			BodySize++;
		}
		std::cout << "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" << std::endl;
		std::cout << "++++++++++++     你已经备份了:" << BodySize / 2 << "份文件,文件详细信息如下：" << std::endl;
		std::cout << "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" << std::endl;
		std::cout << "---------------------------------------------------------------------------------------------------" << std::endl;
		size_t pos1 = 0;
		size_t pos2;
		for (size_t i = 0; i < BodySize / 2; i++) 
		{
			pos2 = rsp->body.find('\n', pos1);
			string FileName = rsp->body.substr(pos1, pos2 - pos1);
			//找文件大小
			pos1 = pos2 + 1;
			pos2 = rsp->body.find('\n', pos1);
			string FileSize = rsp->body.substr(pos1, pos2 - pos1);
			pos1 = pos2 + 1;
			std::cout << "[" << i + 1 << "]:" << FileName << "<->size:" << FileSize << std::endl;
		}
		std::cout << std::endl;
		std::cout << "---------------------------------------------------------------------------------------------------" << std::endl;
	}

	//获取该用户所有文件的下载路径
	void GetClientAllFileDownloadPath()
	{
		std::string DownLoadPath;
		DownLoadPath += "47.98.61.33:16300/NormalFile/";
		DownLoadPath += _EmailName;
		DownLoadPath += "/";
		std::cout << std::endl;
		std::cout << "++++++++++++↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓++++++++++++" << std::endl;
		std::cout << "++++++++++++所有文件下载路径：" << DownLoadPath << std::endl;
		std::cout << "++++++++++++↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓++++++++++++" << std::endl;
	}

	//获取该用户指定文件的下载路径
	void GetClientThisFileDownloadPath(std::string& FileName)
	{
		std::string DownLoadPath;
		DownLoadPath += "47.98.61.33:16300/DownLoad/";
		DownLoadPath += _EmailName;
		DownLoadPath += "/";
		DownLoadPath += FileName;
		std::cout << std::endl;
		std::cout << "++++++++++++↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓++++++++++++" << std::endl;
		std::cout << "++++++++++++【" << FileName << "】文件下载路径：" << DownLoadPath << std::endl;
		std::cout << "++++++++++++↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓++++++++++++" << std::endl;
	}

private:
	std::string _EmailName;
};