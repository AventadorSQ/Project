商品goods(商品编号goods_id，商品名goods_name, 单价unitprice, 商品类别category, 供应商provider)

CREATE TABLE goods(
goods_id int unsigned primary key auto_increment COMMENT '商品编号',
goods_name varchar(64) not null COMMENT '商品名',
unitprice float(6, 2) not null default 0.99 COMMENT '单价',
category varchar(32) not null COMMENT '商品类名',
provider varchar(128) COMMENT '供应商'
);

插入数据：
insert into goods value (1921680001, '程序的自我修养', 49.9, "科技书籍", "中国科技有限公司");
insert into goods value (1921680002, '懒人床上书桌', 69.9, "日常家用", "时尚家具有限公司");
insert into goods value (1921680003, '39感冒灵', 29.9, "常用药品", "感冒灵有限公司");
insert into goods (goods_name, unitprice, category, provider) value ('爱心抱枕', 99.9, "日常家用", "时尚家具有限公司");
insert into goods (goods_name, unitprice, category, provider) value ('止咳糖浆', 69.9, "常用药品", "感冒灵有限公司");

客户customer(客户号customer_id,姓名name,住址address,邮箱email,性别sex，身份证card_id)

CREATE TABLE customer(
customer_id int unsigned primary key auto_increment COMMENT '客户号',
name varchar(16) not null COMMENT '姓名',
address varchar(128) not null COMMENT '住址',
email varchar(32) unique COMMENT '邮箱',
sex enum('男', '女') not null default '男' COMMENT '性别',
card_id varchar(18) unique COMMENT '身份证'
);

插入数据：
insert into customer (name, address, email, card_id) value ('磊儿子', '陕西科技大学6B404', "111111@qq.com", "610528199606066666");
insert into customer (name, address, email, card_id) value ('山儿子', '陕西科技大学6B404', "222222@qq.com", "610528199607070777");
insert into customer (name, address, email, card_id) value ('单儿子', '陕西科技大学6B404', "333333@qq.com", "610528199808080888");

购买purchase(购买订单号order_id,客户号customer_ id,商品号goods_ id,购买数量nums)
CREATE TABLE purchase(
order_id int unsigned primary key auto_increment COMMENT '订单号',
customer_id int unsigned not null COMMENT '客户号',
goods_id int unsigned not null COMMENT '商品号',
nums int not null default 1 COMMENT '购买数量',
foreign key (goods_id) references goods(goods_id),
foreign key (customer_id) references customer(customer_id)
);

插入数据：
insert into purchase value (2019000001, 1, 1921680003, 2);
insert into purchase (customer_id, goods_id) value (1, 1921680004);
insert into purchase (customer_id, goods_id) value (2, 1921680002);
insert into purchase (customer_id, goods_id) value (3, 1921680004);
insert into purchase (customer_id, goods_id) value (3, 1921680003);


每个表的主外键
客户的姓名不能为空值
邮箱不能重复
客户的性别(男，女) 

创建数据库：
CREATE database 数据库名;
例子：
      CREATE databases testbases;